package io.pharmacie;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ActivityComand extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comand);
    }
}
