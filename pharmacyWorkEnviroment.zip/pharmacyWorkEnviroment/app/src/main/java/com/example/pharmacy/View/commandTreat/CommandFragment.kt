package com.example.pharmacy.View.commandTreat

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProviders
import com.example.pharmacy.Model.ApiService.ApiService
import com.example.pharmacy.Model.Commande
import com.example.pharmacy.Model.User
import java.util.*
import com.example.pharmacy.R
import com.example.pharmacy.Repo.RepoCommand

import com.example.pharmacy.Repo.RepoUser
import com.example.pharmacy.ViewModel.ViewModelCommande
import com.example.pharmacy.ViewModel.ViewModelPharmacy

import kotlinx.android.synthetic.main.fragment_command.*
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.*

@SuppressLint("ByteOrderMark")
class CommandFragment : Fragment() {
    private var btn: Button? = null
    private var imageview: ImageView? = null
    private val GALLERY = 1
    private val CAMERA = 2
    private val TAG :String = "MUSTAPHATESTCAMERA"
    val MY_PERMISSIONS_REQUEST_CODE = 123
    var retrofitInterface = ApiService.createAvatar()
    var repoCommand: RepoCommand = RepoCommand()
    var bitmapglobal:Bitmap ?=null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view =  inflater.inflate(R.layout.fragment_command, container, false)


      /*  btn =  view!!.findViewById(R.id.btn) as Button
        imageview =  view!!.findViewById<View>(R.id.iv) as ImageView

        checkPermission()
        btn!!.setOnClickListener { showPictureDialog() }*/
       /* Log.e("CREATETEST","65423")

        repoUsers.createAccount(User("debbih", "mustapha", "fm_debbih@esi.dz","+213675364658","00216520000","JJJJ")
        ).subscribe({
            Log.e("CREATETEST","mustapha sucess")
            Log.e("CREATETEST",it.message)

        }, { error ->
            error.printStackTrace()
        })
        Log.e("CREATETEST","654123")*/
        //btn =  view!!.findViewById(R.id.btn) as Button
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        imageview =  view.findViewById<View>(R.id.image) as ImageView
        var viewModel= ViewModelProviders.of(activity!!).get(ViewModelCommande ::class.java)
        checkPermission()
          camera.setOnClickListener {
              takePhotoFromCamera()
              gallerie.isVisible=!gallerie.isVisible
              camera.isVisible=!camera.isVisible
              annule.isVisible=!annule.isVisible
              send.isVisible=!send.isVisible
          }
        gallerie.setOnClickListener {
            choosePhotoFromGallary()
            gallerie.isVisible=!gallerie.isVisible
            camera.isVisible=!camera.isVisible
            annule.isVisible=!annule.isVisible
            send.isVisible=!send.isVisible
            titre.isVisible=!titre.isVisible
        }
        annule.setOnClickListener {
            gallerie.isVisible=!gallerie.isVisible
            camera.isVisible=!camera.isVisible
            annule.isVisible=!annule.isVisible
            send.isVisible=!send.isVisible
            titre.isVisible=!titre.isVisible
        }
        send.setOnClickListener {
            gallerie.isVisible = !gallerie.isVisible
            camera.isVisible = !camera.isVisible
            annule.isVisible = !annule.isVisible
            send.isVisible = !send.isVisible
            titre.isVisible = !titre.isVisible
            alert()
            val file: File = bitmapToFile(bitmapglobal!!)
            val response = repoCommand.uploadFile(file)
            Log.e("RESPONSE", response.toString())
            Log.e("MUSTAPHAPATH", bitmapToFile(bitmapglobal!!).absolutePath)
            // repoCommand.downloadImage(imageview!!,bitmap)
            //imageview!!.setImageBitmap(bitmapglobal)
            val pref = activity!!.getSharedPreferences("fileName", Context.MODE_PRIVATE)
            val emailLoc = pref.getString("email", "")
            var dayOfMonth = Calendar.getInstance().get(Calendar.DAY_OF_MONTH).toString()
            var month = Calendar.getInstance().get(Calendar.MONTH).toString()
            var year = Calendar.getInstance().get(Calendar.YEAR).toString()
            if (month.length == 1) month = "0$month"
            if (dayOfMonth.length == 1) dayOfMonth = "0$dayOfMonth"
            val date = "$dayOfMonth-$month-$year"
            Log.e("adem", "ademmm")
            val cmd = Commande(titredemande!!.text.toString(), emailLoc!!, "En attente", file.name, date.toString())
            viewModel.createCommand(cmd)
            repoCommand.createCommand(cmd).subscribe {
                Log.e("error", it.toString())
            }

        }
    }


    fun choosePhotoFromGallary() {

        val galleryIntent = Intent(Intent.ACTION_PICK,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        galleryIntent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivityForResult(galleryIntent, GALLERY)
    }

     fun takePhotoFromCamera() {
        Log.e(TAG,"takePhotoFromCamera")
         val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
         intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
         if (ContextCompat.checkSelfPermission(
                 activity!! as Context,Manifest.permission.CAMERA
             )
             == PackageManager.PERMISSION_GRANTED
         )
             startActivityForResult(intent, CAMERA)
         else Toast.makeText(activity!!.applicationContext, "Vous devez autoriser l'application à utilisé la cam", Toast.LENGTH_SHORT).show()

    }

    override fun onActivityResult(requestCode:Int, resultCode:Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        /* if (resultCode == this.RESULT_CANCELED)
         {
         return
         }*/
        if (requestCode == GALLERY)
        {
            if (data != null)
            {
                val contentURI = data.data

                try
                {
                   val bitmap = MediaStore.Images.Media.getBitmap(activity!!.contentResolver, contentURI)
                    imageview!!.setImageBitmap(bitmap)
                    bitmapglobal = bitmap
                   // bitmapglobal  = MediaStore.Images.Media.getBitmap(activity!!.contentResolver, contentURI)
                    //imageview!!.setImageBitmap(bitmapglobal)
                    //ADDED
                   // val path = saveImage(bitmap)
                   // Log.e("MUSTAPHAPATH","this is working here")
                   //  Log.e("MUSTAPHAPATH",path



                    Toast.makeText(activity!!.applicationContext, "Image Saved!", Toast.LENGTH_SHORT).show()
                    /*val file:File = bitmapToFile(bitmap)
                    val response = repoCommand.uploadFile(file)
                    Log.e("RESPONSE",response.toString())
                    Log.e("MUSTAPHAPATH",bitmapToFile(bitmap).absolutePath)
                   // repoCommand.downloadImage(imageview!!,bitmap)
                    imageview!!.setImageBitmabitmapp()*/
                }
                catch (e: IOException) {
                    e.printStackTrace()
                    Toast.makeText(activity!!.applicationContext, "Failed!", Toast.LENGTH_SHORT).show()
                }
            }

        }
          else if (requestCode == CAMERA)
        {
            Log.e(TAG,"REQUEST CAMERA CODE UNTILI HERE IT WORKS")

            if(data != null) {
                val thumbnail = data.extras!!.get("data") as Bitmap
                imageview!!.setImageBitmap(thumbnail)
               // saveImage(thumbnail)
                Toast.makeText(activity!!.applicationContext, "Image Saved!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun bitmapToFile(bitmap:Bitmap): File {
        // Get the context wrapper
        val wrapper = ContextWrapper(activity!!.applicationContext)

        // Initialize a new file instance to save bitmap object
        var file = wrapper.getDir("Images", Context.MODE_PRIVATE)
        file = File(file,"${UUID.randomUUID()}.jpg")

        try{
            // Compress the bitmap and save in jpg format
            val stream: OutputStream = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG,100,stream)
            stream.flush()
            stream.close()
        }catch (e:IOException){
            e.printStackTrace()
        }

        return file
        // Return the saved bitmap uri
        //return Uri.parse(file.absolutePath)
    }


    fun saveImage(myBitmap: Bitmap):String {
        /*Log.e(TAG,"SAVEIMAGE IN ")

           val bytes = ByteArrayOutputStream()
           myBitmap.compress(Bitmap.CompressFormat.JPEG, 90, bytes)
           Log.e("TESTPATH","TEST1")
           val wallpaperDirectory = File(
               Environment().toString() + IMAGE_DIRECTORY)
           // have the object build the directory structure, if needed.
           Log.d(TAG,wallpaperDirectory.toString())
           Log.e("TESTPATH","TEST2")
           if (!wallpaperDirectory.exists())
           {
               Log.e("TESTPATH","WALLPAPER EXISTS")
               Log.d(TAG,"mkdirs wallpaperdirectory")
               wallpaperDirectory.mkdirs()
           }
           try
           {
               Log.d(TAG,wallpaperDirectory.toString())
               val f = File(wallpaperDirectory, ((Calendar.getInstance()
                   .getTimeInMillis()).toString() + ".jpg"))
               f.createNewFile()
               Log.e("TESTPATH","TEST3")
               val fo = FileOutputStream(f)
               fo.write(bytes.toByteArray())
               MediaScannerConnection.scanFile(activity!!,
                   arrayOf(f.getPath()),
                   arrayOf("image/jpeg"), null)
               fo.close()
               Log.d(TAG, "File Saved::--->" + f.getAbsolutePath())
               Log.e("TESTPATH",f.getAbsolutePath())
               return f.getAbsolutePath()
           }
           catch (e1: IOException) {
               Log.e("TESTPATH","TEST4")
               Log.e("TESTPATH",e1.toString())
               e1.printStackTrace()
           }*/
           return ""
    }


    companion object {
        private val IMAGE_DIRECTORY = "/demonuts"
    }

    protected fun checkPermission() {
        if (((ContextCompat.checkSelfPermission(activity!!, Manifest.permission.CAMERA)
                    + ContextCompat.checkSelfPermission(
                activity!!, Manifest.permission.READ_EXTERNAL_STORAGE)) !== PackageManager.PERMISSION_GRANTED))
        {
            // Do something, when permissions not granted
            if ((ActivityCompat.shouldShowRequestPermissionRationale(
                    activity!!, Manifest.permission.CAMERA)
                        || ActivityCompat.shouldShowRequestPermissionRationale(
                    activity!!, Manifest.permission.READ_EXTERNAL_STORAGE)))
            {
                // If we should give explanation of requested permissions
                // Show an alert dialog here with request explanation
                val builder = AlertDialog.Builder(activity!!)
                builder.setMessage(("Camera, Read Contacts and Write External" + " Storage permissions are required to do the task."))
                builder.setTitle("Please grant those permissions")
                builder.setPositiveButton("OK", object: DialogInterface.OnClickListener {
                    override fun onClick(dialogInterface:DialogInterface, i:Int) {
                        ActivityCompat.requestPermissions(
                            activity!!,
                            arrayOf<String>(Manifest.permission.CAMERA,Manifest.permission.READ_EXTERNAL_STORAGE),
                            MY_PERMISSIONS_REQUEST_CODE
                        )
                    }
                })
                builder.setNeutralButton("Cancel", null)
                val dialog = builder.create()
                dialog.show()
            }
            else
            {
                // Directly request for required permissions, without explanation
                ActivityCompat.requestPermissions(
                    activity!!,
                    arrayOf<String>(Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE),
                    MY_PERMISSIONS_REQUEST_CODE
                )
            }
        }
        else
        {
            // Do something, when permissions are already granted
            Toast.makeText(activity!!.applicationContext, "Permissions already granted", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<String>, grantResults:IntArray) {
        when (requestCode) {
            MY_PERMISSIONS_REQUEST_CODE -> {
                // When request is cancelled, the results array are empty
                if (((grantResults.size > 0) && (((grantResults[0]
                            + grantResults[2]) == PackageManager.PERMISSION_GRANTED))))
                {
                    // Permissions are granted
                    Toast.makeText(activity!!.applicationContext, "Permissions granted.", Toast.LENGTH_SHORT).show()
                }
                else
                {
                    // Permissions are denied
                    Toast.makeText(activity!!.applicationContext, "Permissions denied.", Toast.LENGTH_SHORT).show()
                }
                return
            }
        }
    }
    fun alert (){
        val builder = androidx.appcompat.app.AlertDialog.Builder(this.context!!)
        builder.setTitle("Demande Saidaliyati")
        builder.setMessage("Votre demande a été envoyer avec succée ,Nous esaiyons de vous repondre dés que possible")
        builder.setPositiveButton("Continue", null);
        val dialog = builder.create()
        dialog.show()
    }

}