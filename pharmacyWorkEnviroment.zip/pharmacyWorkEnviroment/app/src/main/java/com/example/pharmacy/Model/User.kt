package com.example.pharmacy.Model


data class User(var lastname: String, var firstname: String, var email: String, var phone_number: String, var NSS: String, var password: String) {



}