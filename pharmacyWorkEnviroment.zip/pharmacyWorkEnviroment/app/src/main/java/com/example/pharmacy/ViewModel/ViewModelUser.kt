package com.example.pharmacy.ViewModel

import android.annotation.SuppressLint
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.pharmacy.Model.ApiService.ResponseMessage
import com.example.pharmacy.Model.User
import com.example.pharmacy.Repo.RepoUser

class ViewModelUser : ViewModel() {
    var user =  MutableLiveData<User>()
    var Resp=MutableLiveData<ResponseMessage>()
    var repoUser: RepoUser = RepoUser()

    @SuppressLint("CheckResult")
    /*fun getUser(phone: String,pwd :String): LiveData<User> {
        repoUser!!.getUserByPhonePwd(phone,pwd).subscribe({
            user.postValue(it)
        }, { error ->
            error.printStackTrace()
        })
        return user
    }*/
    fun CreerAcount(user:User):MutableLiveData<ResponseMessage>{
        repoUser.createAccount(user).subscribe ({
            this.Resp.postValue(it)
        }, { error ->
            error.printStackTrace()

        })
      return Resp
    }
    @SuppressLint("CheckResult")
    fun upDateUserPassword(email:String, oldpassword:String, newpassword:String):MutableLiveData<ResponseMessage>{
        repoUser.upDateUserPassword(email,oldpassword,newpassword).subscribe {
          Resp.postValue(it)
        }
        return Resp
    }
    @SuppressLint("CheckResult")
    fun loginUser(email:String, pwd:String):MutableLiveData<ResponseMessage>{
        repoUser.loginUser(email,pwd).subscribe {
            Resp.postValue(it)
        }
        return Resp
    }
}