package com.example.pharmacy.Repo
import com.example.pharmacy.Model.ApiService.ApiService
import com.example.pharmacy.Model.User
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class RepoUser {
    var apiService = ApiService.create()
    constructor()
    fun createAccount(user :User)=apiService.createAccount(user)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribeOn(Schedulers.io())

    fun loginUser(email:String,pwd:String)=apiService.loginUser(email,pwd)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribeOn(Schedulers.io())

    fun upDateUserPassword(email:String,oldpassword:String,newpassword:String)= apiService.upDatePasword(email,oldpassword,newpassword)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribeOn(Schedulers.io())

    fun getUser(email:String,pwd:String)=apiService.getUser(email,pwd)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribeOn(Schedulers.io())
}


