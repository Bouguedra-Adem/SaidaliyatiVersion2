package com.example.pharmacy.Repo.RepoLocal_DataBase

import android.app.Application
import android.content.Context
import android.os.AsyncTask
import android.util.Log
import androidx.lifecycle.LiveData

import androidx.lifecycle.MutableLiveData
import com.example.pharmacy.Model.Pharmacy
import com.example.pharmacy.Model.RoomDataBasePharmacy.DaoPharmacie
import com.example.pharmacy.Model.RoomDataBasePharmacy.DataBase_Instance
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import java.util.*
import kotlin.collections.ArrayList

class RepoPharmacie_Local(context: Context) {
    private val pharmacieDa:DaoPharmacie?
    private val allPharmacie: LiveData<List<Pharmacy>>

    init {
        val db=DataBase_Instance.getInstance(context)


        pharmacieDa=db?.DaoPharmacie()
        this.allPharmacie= pharmacieDa!!.getAllPharmacie()

    }

    fun insertPharmacie(Pharmacie:Pharmacy){
        Log.e("insert", "ademmm")
        inserAsynckTasck(pharmacieDa!!).execute(Pharmacie)
    }

    fun deltePharmacie(Pharmacie:Pharmacy){
        DeleteAsynckTasck(pharmacieDa!!).execute(Pharmacie)

    }
    fun checkExistPharma(pharma:Pharmacy):Boolean?{
        Log.e("heree adem", getAllPharmacie().value.toString())
        return  getAllPharmacie().value!!.contains(pharma)
    }
    fun getAllPharmacie(): LiveData<List<Pharmacy>> {
        return pharmacieDa!!.getAllPharmacie()

    }
    private  class inserAsynckTasck (private val dao: DaoPharmacie): AsyncTask<Pharmacy, Void, Void>(){
        override fun doInBackground(vararg params: Pharmacy?): Void? {
            dao.insertPharmacie(params[0]!!)
            return null
        }

    }
    private  class getAsynckTasck (private val dao: DaoPharmacie): AsyncTask<Pharmacy, Void, Void>(){
        override fun doInBackground(vararg params: Pharmacy?): Void? {
            dao.insertPharmacie(params[0]!!)
            return null
        }

    }
    private  class DeleteAsynckTasck (private val dao: DaoPharmacie): AsyncTask<Pharmacy, Void, Void>(){
        override fun doInBackground(vararg params: Pharmacy?): Void? {
            dao.deltePharmacie(params[0] !!)
            return null

        }

    }


}

