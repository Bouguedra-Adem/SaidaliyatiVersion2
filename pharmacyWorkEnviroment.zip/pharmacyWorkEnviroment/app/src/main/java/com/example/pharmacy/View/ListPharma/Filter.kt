package com.example.pharmacy.View.ListPharma


import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.isVisible
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.ViewModelProviders

import com.example.pharmacy.R
import com.example.pharmacy.ViewModel.ViewModelCommune
import com.example.pharmacy.ViewModel.ViewModelPharmacy

import kotlinx.android.synthetic.main.fragment_filter.*
import java.lang.reflect.Array
import java.util.*
import kotlin.collections.ArrayList
import kotlin.concurrent.schedule
import android.widget.RadioButton
import kotlinx.android.synthetic.main.list_pharma.*


class Filter : DialogFragment(), DatePickerDialog.OnDateSetListener {
    private var radioButton: RadioButton? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_filter, container, false)
    }

    @SuppressLint("SetTextI18n")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)
        textInputLayout2.isVisible=false
        var viewModelPharma= ViewModelProviders.of(activity!!).get(ViewModelPharmacy ::class.java)
        var viewModecommune= ViewModelProviders.of(activity!!).get(ViewModelCommune ::class.java)
        val wilaya: kotlin.Array<String> = arrayOf("Adrar","Chlef","Laghouat","Oum El Bouaghi","Batna","Béjaïa","Biskra","Béchar","Blida","Bouira","Tamanrasset","Tébessa","Tlemcen","Tiaret","Tizi Ouzou","Alger","Djelfa","Jijel","Sétif","Saida","Skikda","Sidi Bel Abbès","Annaba","Guelma","Constantine","Médéa","Mostaganem","Msila","Mascara","Ouargla","Oran","El Bayadh","Illizi","Bordj Bou Arreridj","Boumerdès","El Tarf","Tindouf","Tissemsilt","El Oued","Khenchela","Souk Ahras","Tipaza","Mila","Ain Defla","Naama","Ain Témouchent","Ghardaia","Relizane")
        val adapterWilaya = ArrayAdapter(
            this.context!!,
            R.layout.dropdown_menu_popup_item,
            wilaya
        )
        val editTextFilledExposedDropdownWilaya = filled_exposed_dropdown
        editTextFilledExposedDropdownWilaya.setAdapter(adapterWilaya)

        var CommuneArray = ArrayList<String>()
        editTextFilledExposedDropdownWilaya.setOnItemClickListener { adapterView, view, i, l ->
            textInputLayout2.isVisible=true
            Log.e("nomwilya",editTextFilledExposedDropdownWilaya.text.toString())
            Log.e("index",wilaya.indexOf(editTextFilledExposedDropdownWilaya.text.toString()).toString())
        viewModecommune.getCommuneByWilaya((wilaya.indexOf(editTextFilledExposedDropdownWilaya.text.toString())+1).toString()).observe(activity!!,androidx.lifecycle.Observer {
            Log.e("nomwilya",editTextFilledExposedDropdownWilaya.text.toString())
            CommuneArray.removeAll(CommuneArray)
            it.forEach {
                CommuneArray.add(it.nomCommune.toString())
            }
        })

        val adapter = ArrayAdapter(
            this.context!!,
            R.layout.dropdown_menu_popup_item,
            CommuneArray
        )

        val editTextFilledExposedDropdown = filled_exposed_dropdown2
            filled_exposed_dropdown2.setAdapter(adapter)
        }
        filled_exposed_dropdown2.setOnDismissListener {

        }
        datePicker.setOnClickListener{

            showDialgPicker()
        }
        ValideFiltre.setOnClickListener{

            var id: Int = radioGroup.checkedRadioButtonId
            if (id!=-1){ radioButton= view.findViewById(id) }

            if (setdate.text.toString()=="") {
                var dayOfMonth = Calendar.getInstance().get(Calendar.DAY_OF_MONTH).toString()
                var month = Calendar.getInstance().get(Calendar.MONTH).toString()
                var year = Calendar.getInstance().get(Calendar.YEAR).toString()
                if (month.length==1) month= "0$month"
                if (dayOfMonth.length==1)dayOfMonth="0$dayOfMonth"
                val date = "$dayOfMonth-$month-$year"
                setdate.text = "30-07-2019"
                Log.e("dateis",date)
            }

            if ( wilaya.indexOf(editTextFilledExposedDropdownWilaya.text.toString())==-1 && setdate.text.isNotEmpty())
                viewModelPharma.getPharmaciesGardeBydate(setdate.text.toString())
            else
                if(wilaya.indexOf(editTextFilledExposedDropdownWilaya.text.toString())!=-1 && setdate.text.isEmpty() && filled_exposed_dropdown2.text.toString().isNotEmpty() )
                    viewModelPharma.getAllPHarmaciesByFilterNotGard(filled_exposed_dropdown2.text.toString(),radioButton!!.text.toString())
            else
                if(wilaya.indexOf(editTextFilledExposedDropdownWilaya.text.toString())!=-1 && setdate.text.isNotEmpty() && filled_exposed_dropdown2.text.toString().isNotEmpty() )
                viewModelPharma.getAllPHarmaciesByFilter(filled_exposed_dropdown2.text.toString(),setdate.text.toString(),radioButton!!.text.toString())


            viewModelPharma.showCancelFilterFromThread(true)
            Timer("DialogCancel", false).schedule(1000) { dismiss() }

        }

        cancelFiltre.setOnClickListener {
            Timer("DialogCancel", false).schedule(500) {
                dismiss()

            }
        }



    }
   fun showDialgPicker(){
       val datePicker:DatePickerDialog= DatePickerDialog(activity!!,this,
           Calendar.getInstance().get(Calendar.YEAR),
           Calendar.getInstance().get(Calendar.MONTH),
           Calendar.getInstance().get(Calendar.DAY_OF_MONTH))
       datePicker.show()
   }
    override  fun onDateSet(view: DatePicker, year: Int, month: Int, dayOfMonth: Int) {
        var monthh:String = if (month.toString().length==1) "0$month" else "$month"
        var dayOfMonthh:String=if (dayOfMonth.toString().length==1) "0$dayOfMonth" else "$dayOfMonth"
        val date = "$dayOfMonthh-$monthh-$year"
        setdate.text = date

    }

}
