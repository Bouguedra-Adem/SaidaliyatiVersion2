package com.example.pharmacy.View.User


import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import androidx.navigation.NavOptions
import androidx.navigation.fragment.findNavController

import com.example.pharmacy.R
import com.example.pharmacy.Repo.RepoUser
import com.example.pharmacy.View.MainActivity
import kotlinx.android.synthetic.main.fragment_login.*
import kotlinx.android.synthetic.main.fragment_login.motdepass


class Login : Fragment() {
    var repoUser: RepoUser = RepoUser()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_login, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        auth.setOnClickListener {
            Authentification()
        }
        creerAcount.setOnClickListener {
            Log.e("ggg","im here")
            CreerCompte()
        }
    }
    @SuppressLint("CheckResult")
    fun Authentification(){
        if (motdepass.text!!.isNotEmpty() && emailadr!!.text!!.isNotEmpty() ){
           this.repoUser.loginUser(emailadr!!.text.toString(),motdepass!!.text.toString()).subscribe({
             Log.e("it",it.result.toString())
              if (it.result){
               val pref = activity!!.getSharedPreferences("fileName", Context.MODE_PRIVATE)
               pref.edit {
                   putBoolean("connected",true)
                   putString("email",emailadr.text.toString())
                   putString("pwd",motdepass.text.toString())
               }
               val intent = Intent(activity!!, MainActivity::class.java)
                  activity!!.overridePendingTransition(R.anim.slide_in_top, R.anim.slide_out_top);
                  startActivity(intent)
                  activity!!.overridePendingTransition(R.anim.slide_out_top, R.anim.slide_in_top);
           }
               else {
               Log.e("msg error",it.message)
           }

           },{ error ->
               error.printStackTrace()
           })
        }

    }
    fun CreerCompte(){

            activity!!.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
            // Handler().postDelayed({
            //start fragment
            findNavController()
                .navigate(
                    R.id.action_login_to_splashScreen22,
                    null,
                    NavOptions.Builder()
                        .setEnterAnim(R.anim.slide_out_top)
                        .setPopEnterAnim(R.anim.slide_out_top)
                        .setExitAnim(R.anim.slide_in_top)
                        .setPopExitAnim(R.anim.slide_in_top)
                        .build()
                )
            //finish this activity
            activity!!.window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            (activity as AppCompatActivity).supportActionBar!!.hide()
            //(activity as AppCompatActivity).onSupportNavigateUp()

            //  }, 2000)

    }
}
