package com.example.pharmacy.ViewModel

import android.annotation.SuppressLint
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.pharmacy.Model.Commune
import com.example.pharmacy.Model.Pharmacy
import com.example.pharmacy.Repo.RepoCommune

class ViewModelCommune : ViewModel()  {

    var Communes = MutableLiveData<List<Commune>>()
    var repoCommune : RepoCommune = RepoCommune()
    init {
        Communes=getCommuneAll()
    }

    @SuppressLint("CheckResult")
    fun getCommuneAll(): MutableLiveData<List<Commune>> {
        repoCommune.getAllCommues().subscribe({

            Communes.postValue(it)
        }, { error ->
            error.printStackTrace()
        })
        return Communes
    }
    @SuppressLint("CheckResult")
    fun getCommuneByWilaya(wilaya:String): MutableLiveData<List<Commune>> {
        repoCommune.getCommuesByWilaya(wilaya).subscribe({

            Communes.postValue(it)
        }, { error ->
            error.printStackTrace()
        })
        return Communes
    }

}