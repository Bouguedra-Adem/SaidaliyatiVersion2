package com.example.pharmacy.ViewModel

import android.annotation.SuppressLint
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.pharmacy.Model.Pharmacy
import com.example.pharmacy.Repo.RepoPharmacie
import io.reactivex.functions.Consumer

class ViewModelPharmacy : ViewModel() {

    var Pharmacie = MutableLiveData<List<Pharmacy>>()
    var PharmacieGarde = MutableLiveData<List<Pharmacy>>()
    var ShowCancelFromThread= MutableLiveData<Boolean>()
    var repoPharma: RepoPharmacie = RepoPharmacie()

    init {
       Pharmacie=getAllPharmacy()
    }

    @SuppressLint("CheckResult")
    fun getAllPharmacy(): MutableLiveData<List<Pharmacy>> {
        repoPharma!!.getAllPharamacy().subscribe({

            Pharmacie.postValue(it)
        }, { error ->
            error.printStackTrace()
        })
        return Pharmacie
    }
    @SuppressLint("CheckResult")
    fun getPharmacy(commune: String): MutableLiveData<List<Pharmacy>> {
        repoPharma!!.getPharamacyByCommune(commune).subscribe({

            Pharmacie.postValue(it)
        }, { error ->
            error.printStackTrace()
        })
        return Pharmacie
    }

    @SuppressLint("CheckResult")
    fun getPharmaciesGardeBydate(dateGarde: String): MutableLiveData<List<Pharmacy>> {
        repoPharma!!.getPharmaciesGardeBydate(dateGarde).subscribe({

            Pharmacie.postValue(it)
        },{error ->
            error.printStackTrace()

        })
        return Pharmacie
    }
    @SuppressLint("CheckResult")
    fun getAllPHarmaciesByFilter(commune:String,dateGarde: String,Convention:String): MutableLiveData<List<Pharmacy>> {
        Log.e("keyyy",commune+" "+dateGarde+" "+Convention)

        repoPharma!!.getAllPharamacyByFilter(commune,dateGarde,Convention).subscribe({

            Pharmacie.postValue(it)
        },{error ->
            error.printStackTrace()

        })
        return Pharmacie
    }
   fun getAllPHarmaciesByFilterNotGard(commune:String,Convention:String): MutableLiveData<List<Pharmacy>> {
       repoPharma!!.getAllPharamacyByFilterDateGard(commune,Convention).subscribe({

           Pharmacie.postValue(it)
       },{error ->
           error.printStackTrace()

       })
       return Pharmacie
   }
   fun showCancelFilterFromThread(bol:Boolean):MutableLiveData<Boolean>{
       this.ShowCancelFromThread!!.value=bol
       return this.ShowCancelFromThread
   }



}