package com.example.pharmacy.View.Map

import android.Manifest
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.navigation.fragment.NavHostFragment
import com.example.pharmacy.Model.User
import com.example.pharmacy.R
import com.example.pharmacy.Repo.RepoUser
import com.example.pharmacy.ViewModel.ViewModelPharmacy
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import kotlinx.android.synthetic.main.activity_main.*
import java.io.IOException
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*

class MapFragment : Fragment(), OnMapReadyCallback {
    private lateinit var mMap: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var lastLocation: Location
    private val ZOOM:Float  = 12f
    var viewmodelpharmacyGarde: ViewModelPharmacy = ViewModelPharmacy()
    private val TAG : String="MUSTAPHAMAP"
    private var adresses = arrayOfNulls<String>(100)
    val MY_PERMISSIONS_REQUEST_CODE = 123


    //TEST
    var repoUser : RepoUser = RepoUser()

    //END TEST

    companion object {
        var mapFragment : SupportMapFragment?=null
        //val TAG: String = MapFragment::class.java.simpleName
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1
        fun newInstance() = MapFragment()
    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        var rootView = inflater.inflate(R.layout.fragment_map, container, false)
        initMap()

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this.activity!!)


        return rootView
    }


    private fun initMap() {
        mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(this)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
           Log.e("adeouma","dffffffffffff")
           menu.findItem(R.id.app_bar_search).setVisible(false)
           menu.findItem(R.id.app_bar_search).setVisible(false)
           menu.findItem(R.id.profile).setVisible(false)

    }
    override fun onMapReady(googleMap: GoogleMap?){

        mMap = googleMap!!
        setUpMap()


        if (arguments!=null && arguments!!.getString("Adr")!="" ){
            Log.e("AdrrrMap",arguments!!.getString("Adr"))
            showPharmacy(arguments!!.getString("Adr"))
        }
        else{
            //getMyCurrentLocation()
            Log.e(TAG,"OnMapReadyyyyyyyyy")
            getPharmcyGard()
        }

    }

    private fun setUpMap() {
        if (ActivityCompat.checkSelfPermission(activity!!,
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity!!,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION_REQUEST_CODE)
            return
        }
    }

    private fun getMyCurrentLocation(){

        if (ActivityCompat.checkSelfPermission(activity!!,
                android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            mMap.isMyLocationEnabled = true
            fusedLocationClient.lastLocation.addOnSuccessListener(activity!!) { location ->
                // Got last known location. In some rare situations this can be null.
                // 3
                if (location != null) {

                    lastLocation = location
                    val currentLatLng = LatLng(lastLocation.latitude, lastLocation.longitude)
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, ZOOM))
                }
            }
        }

    }

    private fun closestOnCallPharmacy(){}

    private fun showPharmacy(adressPharmacy:String?){
        val geocoder = Geocoder(activity!!.applicationContext)
        var list: List<Address>

        //val closectPHarmacy: Address? = null
        try {
            Log.d(TAG, "address found")
            list = geocoder.getFromLocationName(adressPharmacy, 1)
            if (list.size > 0) {
                val adr = list[0]
                Log.d(TAG, adr.toString())
                moveCamera(LatLng(adr.latitude, adr.longitude), "mustapha")
            }
        } catch (e: IOException) {
            Log.d(TAG, "IOException: $e")
        }

    }

    private fun moveCamera(latlng: LatLng,title: String) {
        Log.d(TAG, "moveCamera: moving the camera ot: 1st")
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latlng, ZOOM))
        //if (title != resources.getString(R.string.myLocation)){
            val options = MarkerOptions()
                .position(latlng)
                .title(title)
            mMap.addMarker(options)
        //}
    }

    private fun getPharmcyGard(){
        Log.e(TAG,"getPharmacyGARD IN")
        val c = Calendar.getInstance().time

        val df = SimpleDateFormat("dd-MM-yyyy")

        val formattedDate = df.format(c)

        Log.e("MUSTAPHAAMINE", "the date of today  :$formattedDate")
        //val datagard:String = "06-05-2019"
        this.viewmodelpharmacyGarde= ViewModelProviders.of(this).get( ViewModelPharmacy::class.java)
        this.viewmodelpharmacyGarde.getPharmaciesGardeBydate(formattedDate).observe(this, Observer {
        //this.viewmodelpharmacyGarde.getPharmacy("EL MADANIA").observe(this, Observer {
            Log.e(TAG,it.toString())
            var i: Int = 0
            it.forEach {
                Log.e(TAG,it.toString())
                adresses[i] = it.adresse
                i++
            }

            Log.e(TAG,"getPharmacyGARD OUT")
            closestAddress()
        })
    }

    fun closestAddress(){

        Log.e(TAG,"ClosestAddress IN")
        if (ActivityCompat.checkSelfPermission(activity!!,
                android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            mMap.isMyLocationEnabled = true
            fusedLocationClient.lastLocation.addOnSuccessListener(activity!!) { location ->
                // Got last known location. In some rare situations this can be null.
                // 3
                if (location != null) {

                    lastLocation = location

                    var distance = 0.0
                    var distanceCaculated: Double
                    //val currentLatLng = LatLng(lastLocation.latitude, lastLocation.longitude)
                    val geocoder = Geocoder(activity!!.applicationContext)

                    var closectPHarmacy: Address? = null
                    var list: List<Address>
                    Log.e(TAG, "THIS IS CLOSENT PHARMACY" + adresses[0])
                    for (adress in adresses) {
                        try {
                            if (adress != null) {
                                list = geocoder.getFromLocationName(adress, 1)
                                if (list.size > 0) {
                                    val adr = list[0]
                                    if (adr == null || lastLocation == null) {
                                        if (adr == null)
                                            Log.e(TAG, "adr null")
                                        else
                                            Log.e(TAG, "currentlocation null")
                                    } else {
                                        distanceCaculated = CalculationByDistance(
                                            LatLng(adr.latitude, adr.longitude),
                                            LatLng(lastLocation.getLatitude(), lastLocation.getLongitude())
                                        )
                                        if (distance == 0.0 || distance > distanceCaculated) {
                                            distance = distanceCaculated
                                            Log.e(TAG, adress + "this is its destance " + distance)
                                            closectPHarmacy = adr
                                        }
                                    }
                                }
                            }
                        } catch (e: IOException) {
                            Log.e(TAG, "Address: $adress  $e")
                        }

                    }

                    if (closectPHarmacy != null)
                        moveCamera(LatLng(closectPHarmacy.latitude, closectPHarmacy.longitude), "this is the closest pharmacy")
                    else
                        Log.e(TAG, "adr is null")

                   // mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, ZOOM))
                }
            }
        }
    }

    fun CalculationByDistance(StartP: LatLng, EndP: LatLng): Double {
        val Radius = 6371// radius of earth in Km
        val lat1 = StartP.latitude
        val lat2 = EndP.latitude
        val lon1 = StartP.longitude
        val lon2 = EndP.longitude
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + (Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2)
                * Math.sin(dLon / 2))
        val c = 2 * Math.asin(Math.sqrt(a))
        val valueResult = Radius * c
        val km = valueResult / 1
        val newFormat = DecimalFormat("####")
        val kmInDec = Integer.valueOf(newFormat.format(km))
        val meter = valueResult % 1000
        val meterInDec = Integer.valueOf(newFormat.format(meter))
        Log.i(
            "Radius Value", "" + valueResult + "   KM  " + kmInDec
                    + " Meter   " + meterInDec
        )

        return Radius * c
    }


}
