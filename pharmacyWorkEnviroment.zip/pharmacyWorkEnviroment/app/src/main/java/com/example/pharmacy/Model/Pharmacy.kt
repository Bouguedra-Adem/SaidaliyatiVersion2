package com.example.pharmacy.Model

import androidx.annotation.NonNull
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Pharmacy(
    @PrimaryKey  var nomPrenomPharmacien: String, var heure: String, var adresse: String, var numeroTelephone: String,
    var facebookUrl: String, var caisseConventionnee: String, var dateGarde: String
) {}
