package com.example.pharmacy.Model

class Commune(var nomCommune: String?,var wilayacode: Int) {}
