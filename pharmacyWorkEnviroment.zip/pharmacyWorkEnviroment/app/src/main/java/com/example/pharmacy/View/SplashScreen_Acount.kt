package com.example.pharmacy.View

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.core.content.edit
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import com.example.pharmacy.R
import com.example.pharmacy.ViewModel.ViewModelUser
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.iid.FirebaseInstanceId




class SplashScreen_Acount : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen__acount)
        val nav = Navigation.findNavController(this,R.id.fragment2)
        var viewModel= ViewModelProviders.of(this).get(ViewModelUser::class.java)
        /* FirebaseInstanceId.getInstance().instanceId
            .addOnCompleteListener(OnCompleteListener { task ->
                if (!task.isSuccessful) {
                    //To do//
                    return@OnCompleteListener
                }
                // Get the Instance ID token//
                val token = task.result!!.token
                val msg = getString(R.string.fcm_token, token)
                Log.d("tag", msg)
            })*/

    }
}
