package com.example.pharmacy.View

import android.annotation.SuppressLint
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.core.content.edit
import androidx.core.view.isVisible
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import androidx.navigation.findNavController
import androidx.navigation.ui.NavigationUI
import androidx.navigation.ui.navigateUp
import com.example.pharmacy.R
import com.example.pharmacy.Repo.RepoUser
import com.example.pharmacy.ViewModel.ViewModelCommune
import com.example.pharmacy.ViewModel.ViewModelPharmacy
import com.example.pharmacy.ViewModel.ViewModelUser
import kotlinx.android.synthetic.main.activity_main.*

import com.google.android.material.navigation.NavigationView


class MainActivity : AppCompatActivity(), LifecycleOwner, NavigationView.OnNavigationItemSelectedListener {


    var viewmodel:ViewModelPharmacy= ViewModelPharmacy()
    var viewmode2:ViewModelUser = ViewModelUser()
    var viewmode3:ViewModelCommune = ViewModelCommune()
    var repoUser:RepoUser= RepoUser()
    var navigationView:NavigationView ?= null
    val MY_PERMISSIONS_REQUEST_CODE = 123



    @SuppressLint("CheckResult", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
         val mDrawerLayout= findViewById(R.id.drawerLayout) as DrawerLayout;
         mDrawerLayout.closeDrawers()
         toolbar.isVisible=false
        val nav = Navigation.findNavController(this,R.id.fragment)
        NavigationUI.setupActionBarWithNavController(this,nav)
        NavigationUI.setupActionBarWithNavController(this,nav,drawerLayout)
        NavigationUI.setupWithNavController(nav_view,nav)
        this.viewmodel= ViewModelProviders.of(this).get( ViewModelPharmacy::class.java)
        onSupportNavigateUp()
        this.navigationView = findViewById<View>(R.id.nav_view) as NavigationView
        navigationView!!.setNavigationItemSelectedListener(this)
        val pref = getSharedPreferences("fileName", Context.MODE_PRIVATE)
        val con = pref.getBoolean("connected", false)
        if (!con){
         hideItemCommande()
        }else {
            Log.e("info",pref.getString("email","" )+" "+pref.getString("pwd", "")!!)

            val hView =  navigationView!!.getHeaderView(0);
            val Nameheader=hView.findViewById<TextView>(R.id.nameHeader)
            val Emailheader=hView.findViewById<TextView>(R.id.emailHeader)



            showItemCommande()
            this.repoUser.getUser(pref.getString("email","" ).toString()!!, pref.getString("pwd", "").toString()!!).subscribe({

                Nameheader.text=it.firstname+" "+it.lastname
                Emailheader.text=it.email
            }, { error ->
                error.printStackTrace()
            })
        }

    }


    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.fragment)
        return navController.navigateUp() || navController.navigateUp(drawerLayout)
    }
    override fun onBackPressed() {
        super.onBackPressed()
    }
    fun hideItemCommande(){


        val menu = navigationView!!.menu
         menu.findItem(R.id.deconnecte).isEnabled=false
        menu.findItem(R.id.notification).isEnabled=false
        menu.findItem(R.id.camandList).isEnabled  = false
    }
    fun showItemCommande(){
        val menu = navigationView!!.menu
        menu.findItem(R.id.deconnecte).isEnabled=true
        menu.findItem(R.id.notification).isEnabled=true
         menu.findItem(R.id.camandList).isEnabled = true

    }
    fun showinfoHeader(){

    }
    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        Log.e("ad","aaaaaaaaaaaaaaaaaaaa")
        if (item.itemId==R.id.deconnecte){
            val pref = getSharedPreferences("fileName", Context.MODE_PRIVATE)
            pref.edit {
                putBoolean("connected", false)
            }
            val mDrawerLayout= findViewById(R.id.drawerLayout) as DrawerLayout;
           // Timer("DialogCancel", false).schedule(500) { mDrawerLayout.closeDrawers()}
            mDrawerLayout.closeDrawers()
            finish();
            overridePendingTransition(R.anim.slide_in_top, R.anim.slide_out_top);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_top, R.anim.slide_out_top);

        }
        else{
            val navController = findNavController(R.id.fragment)
             navController.navigate(item.itemId,null,
                 NavOptions.Builder()
                     .setPopUpTo(
                         R.id.splashScreen12,
                         true
                     ).setEnterAnim(R.anim.slide_out_top)
                     .setPopEnterAnim(R.anim.slide_out_top)
                     .setExitAnim(R.anim.slide_in_top)
                     .setPopExitAnim(R.anim.slide_in_top)
                     .build()
             )
            val mDrawerLayout= findViewById(R.id.drawerLayout) as DrawerLayout;
            //Timer("DialogCancel", false).schedule(500) { mDrawerLayout.closeDrawers()}
            mDrawerLayout.closeDrawers()

        }
        return true
    }


}
