package com.example.pharmacy.Model.ApiService


import com.example.pharmacy.Model.Commune
import com.example.pharmacy.Model.Pharmacy
import com.example.pharmacy.Model.Commande
import com.example.pharmacy.Model.User
import io.reactivex.Observable
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import okhttp3.MultipartBody
import okhttp3.OkHttpClient

import okhttp3.ResponseBody

import retrofit2.Call
import retrofit2.http.*

import retrofit2.http.POST
import retrofit2.http.Multipart

/*import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.http.Multipart
import retrofit2.http.POST*/
import retrofit2.http.Part
import java.util.concurrent.TimeUnit


interface ApiService {

    @GET("/login/{email}/{pwd}")
    fun loginUser(@Path(value = "email",encoded = true) email: String,
                  @Path(value = "pwd",encoded = true) pwd: String): Observable<ResponseMessage>
    @GET("/getUser/{email}/{pwd}")
    fun getUser(@Path(value = "email") email: String,
                @Path(value = "pwd") pwd: String): Observable<User>
    @GET("/updatePassword/{useremail}/{lastpassword}/{newpassword}")
    fun upDatePasword(@Path(value="useremail",encoded = true) useremail:String,
                      @Path(value="lastpassword", encoded = true) lastpassword:String,
                      @Path(value="newpassword" , encoded = true) newpassword:String): Observable<ResponseMessage>

    @GET("/communes")
    fun getCommunes(): Observable<List<Commune>>
    @GET("/communes/{codewilaya}")
    fun getCommunesByWilaya(@Path(value = "codewilaya", encoded = true) codewilaya:String): Observable<List<Commune>>


    @GET("/pharmacies/{commune}")
     fun getPharmacies(@Path(value = "commune", encoded = true) commune: String):Observable<List<Pharmacy>>

    @GET("/pharmacies")
    fun getAllPharmacies():Observable<List<Pharmacy>>

    @GET("/Pharmacy/{nomCommune}/{dateGarde}/{TypeConvention}")
    fun getAllPharmaciesByFilter(@Path(value = "nomCommune", encoded = true) nomCommune: String,@Path(value = "dateGarde", encoded = true) dateGarde: String,@Path(value = "TypeConvention", encoded = true) TypeConvention: String):Observable<List<Pharmacy>>

    @GET("/pharmaciegarde/{dateGarde}")
      fun getPharmaciesGarde(@Path(value = "dateGarde", encoded = true) dateGarde: String):Observable<List<Pharmacy>>

    @GET("/PharmacySansDateGard/{nomCommune}/{typeConvention}")
    fun getAllPharmaciesByFilterDateGard(@Path(value = "nomCommune", encoded = true) nomCommune: String,@Path(value = "TypeConvention", encoded = true) TypeConvention: String):Observable<List<Pharmacy>>

    @POST("/users")
      fun createAccount(@Body user: User): Observable<ResponseMessage>


    @POST("/command")
    fun createCommand(@Body cmd: Commande): Observable<ResponseMessage>

    @GET(" /command/userEmail/{userEmail}")
    fun getCmdUserEmail(@Path(value = "userEmail") userEmail: String): Observable<List<Commande>>

    @GET("/command/nomCmd/{nomCmd}")
    fun getCmdNon(@Path(value = "nomCmd") nomCmd: String): Observable<Commande>


    @GET("/sendimg/{imageName}")
    fun getImage(@Path("imageName") imageName:String): Call<ResponseBody>



    @Multipart
    @POST("/upload-avatar")
    fun upload(
        @Part file: MultipartBody.Part
    ): Call<ResponseUpload>





    companion object Factory {
        fun create(): ApiService {
            val retrofit = Retrofit.Builder()
                .baseUrl("https://ancient-harbor-80131.herokuapp.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build()
            return retrofit.create(ApiService::class.java)
        }


        fun createAvatar(): ApiService{
            val okHttpClient = OkHttpClient.Builder()
                .connectTimeout(1, TimeUnit.MINUTES)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .build()
            val retrofit = Retrofit.Builder()
                .baseUrl("https://ancient-harbor-80131.herokuapp.com/")
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            var retrofitInterface = retrofit.create(ApiService::class.java)
            return retrofitInterface
        }
    }
}
