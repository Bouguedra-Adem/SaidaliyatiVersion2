package com.example.pharmacy.View.commandTreat

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.pharmacy.Model.Commande
import com.example.pharmacy.R
import com.example.pharmacy.ViewModel.ViewModelCommande
import kotlinx.android.synthetic.main.camand_list.*
import kotlinx.android.synthetic.main.camand_list.view.*


class CamandList : Fragment() {
    var Data:ArrayList<Commande>?=null
    private var recycler_view: RecyclerView? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.camand_list, container, false)

    }

    @SuppressLint("WrongConstant")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        var viewModel= ViewModelProviders.of(activity!!).get(ViewModelCommande ::class.java)
        var Data=ArrayList<Commande>()
            val pref = activity!!.getSharedPreferences("fileName", Context.MODE_PRIVATE)
            val email = pref.getString("email","")
            viewModel.getAllCommand(email!!).observe(activity!!, Observer {

                Log.e("listpharma", it.toString())
                this.Data = it as ArrayList<Commande>
                recycler_view=view.listcmd
                recycler_view!!.layoutManager = LinearLayoutManager(context, LinearLayout.VERTICAL, false)
                recycler_view!!.adapter = CamandListRecyclerViewAdapter( this.Data!!)

    })
    }








}
