package com.example.pharmacy.View.ListPharma

import android.annotation.SuppressLint
import android.app.Application
import android.os.Bundle
import android.util.Log
import android.view.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import android.widget.LinearLayout
import androidx.core.view.isVisible
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.onNavDestinationSelected
import com.example.pharmacy.Model.Pharmacy
import com.example.pharmacy.R
import com.example.pharmacy.ViewModel.ViewModelPharmacy
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.list_pharma.*
import com.example.pharmacy.Model.User
import androidx.core.view.MenuItemCompat.getActionView
import android.content.Context.SEARCH_SERVICE
import androidx.core.content.ContextCompat.getSystemService
import android.app.SearchManager

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.widget.SearchView
import androidx.core.view.MenuItemCompat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.concurrent.schedule

import android.os.Message

import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import androidx.navigation.ui.NavigationUI.setupActionBarWithNavController
import com.example.pharmacy.R.id.fragment
import com.example.pharmacy.Repo.RepoLocal_DataBase.RepoPharmacie_Local
import com.example.pharmacy.View.MainActivity
import com.example.pharmacy.View.SplashScreen_Acount
import com.example.pharmacy.View.User.Profile


@Suppress("DEPRECATION")
class list_pharma : Fragment(), SearchView.OnQueryTextListener {


    private val updateUIHandler: Handler? = null
    var Data:ArrayList<Pharmacy>?=null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.list_pharma, container, false)
    }

    @SuppressLint("WrongConstant")
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        setHasOptionsMenu(true)

        var viewModel= ViewModelProviders.of(activity!!).get(ViewModelPharmacy ::class.java)
        var Data=ArrayList<Pharmacy>()
        if (verifyAvailableNetwork(AppCompatActivity())) {
            viewModel.Pharmacie.observe(activity!!, Observer {

                Log.e("listpharma", it.toString())
                this.Data = it as ArrayList<Pharmacy>
                list.layoutManager = LinearLayoutManager(context, LinearLayout.VERTICAL, false)
                list.adapter = list_pharma_adapter(this, this.Data!!)
                (list.adapter as list_pharma_adapter).notifyDataSetChanged()

                Log.e("dataromlist", (it).toString())

            })
        }
        else{
            Log.e("dataromlist", "herrrrrrrrrrrrre")
            val RepoLocal= RepoPharmacie_Local(this.context!!)
            RepoLocal.getAllPharmacie().observe(this, Observer {
                this.Data=it as ArrayList<Pharmacy>
                list.layoutManager = LinearLayoutManager(context, LinearLayout.VERTICAL, false)
                list.adapter = list_pharma_adapter(this, this.Data!!)
                (list.adapter as list_pharma_adapter).notifyDataSetChanged()
            })

        }

        filter.setOnClickListener{
          val dialogFragment = Filter()
          dialogFragment.allowEnterTransitionOverlap
          dialogFragment.show(fragment.childFragmentManager, "simple dialog")
              //cancelFilter.isVisible=true


        }
      viewModel.ShowCancelFromThread.observe(this, Observer {
          cancelFilter.isVisible = it
      })
      cancelFilter.setOnClickListener {

          viewModel.getAllPharmacy()
          viewModel.showCancelFilterFromThread(false)


      }

    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.search,menu)
        val searchItem = menu.findItem(R.id.app_bar_search)
        val profile = menu.findItem(R.id.profile)
        val searchView = getActionView(searchItem) as SearchView
        searchView.setOnQueryTextListener(this)


        searchItem.setOnActionExpandListener(object : MenuItem.OnActionExpandListener {
            override fun onMenuItemActionExpand(item: MenuItem?): Boolean {
                Log.e("je sui la","onMenuItemActionExpand")
                return true
            }

            override fun onMenuItemActionCollapse(item: MenuItem?): Boolean {
                Log.e("je sui la","onMenuItemActionCollapse")
                list_pharma_adapter(this@list_pharma,this@list_pharma.Data!!)
                return true
            }
        })
        profile.setOnMenuItemClickListener {
            val pref = activity!!.getSharedPreferences("fileName", Context.MODE_PRIVATE)
            val con = pref.getBoolean("connected", false)
            if (!con) {
                val intent = Intent(activity!!, SplashScreen_Acount::class.java)
                activity!!.overridePendingTransition(R.anim.slide_in_top, R.anim.slide_out_top)
                startActivity(intent)
                activity!!.overridePendingTransition(R.anim.slide_out_top, R.anim.slide_in_top)
            }
            else{
                findNavController().navigate(R.id.action_list_pharma_to_profile2,null, NavOptions.Builder()
                    .setEnterAnim(R.anim.slide_out_top)
                    .setPopEnterAnim(R.anim.slide_out_top)
                    .setExitAnim(R.anim.slide_in_top)
                    .setPopExitAnim(R.anim.slide_in_top)
                    .build()
                )
            }
            true
        }
    }
    override fun onQueryTextSubmit(p0: String?): Boolean {
      return false
    }

    @SuppressLint("WrongConstant")
    override fun onQueryTextChange(newTextsearch: String?): Boolean {
        Log.e("search",newTextsearch)

        var viewModel= ViewModelProviders.of(activity!!).get(ViewModelPharmacy ::class.java)
        viewModel.Pharmacie.observe(activity !!, Observer {
            this.Data=it as ArrayList<Pharmacy>
            Log.e("search",this.Data.toString())
        })

        var newText= newTextsearch!!.toLowerCase()
        if (newText ==null|| newText.trim().isEmpty()) {
            Log.e("je sui la",newTextsearch)
            list.layoutManager =LinearLayoutManager(context, LinearLayout.VERTICAL,false)
            list.adapter=list_pharma_adapter(this, this.Data!!)
            (list.adapter as list_pharma_adapter).notifyDataSetChanged()
            return false
        }
        var filteredNewsList = arrayListOf<Pharmacy>()


        this.Data!!.forEach{
            Log.e("model",this.Data.toString())
            Log.e("model",it.toString())
            //filteredNewsList!!.add(it)
            val nom = it.nomPrenomPharmacien.toLowerCase()
            val adr = it.adresse.toLowerCase()
            val caisse = it.caisseConventionnee.toLowerCase()
            Log.e("compariasson",nom.toString()+"  "+newText.toString())
            if (nom.contains(newText) || adr.contains(newText) || caisse.contains(newText))
            {
                Log.e("modelFROMif",it.toString())

                filteredNewsList.add(it)
                Log.e("filteredNewsList",filteredNewsList.toString())
              /*  //list_pharma_adapter(this,filteredNewsList!!).notifyDataSetChanged()
                list.layoutManager =LinearLayoutManager(context, LinearLayout.VERTICAL,false)
                list.adapter=list_pharma_adapter(this, filteredNewsList!!)
                (list.adapter as list_pharma_adapter).notifyDataSetChanged()*/

            }
        }
        list.layoutManager =LinearLayoutManager(context, LinearLayout.VERTICAL,false)
        list.adapter=list_pharma_adapter(this, filteredNewsList!!)
        (list.adapter as list_pharma_adapter).notifyDataSetChanged()
        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return super.onOptionsItemSelected(item)
    }
    fun verifyAvailableNetwork(activity:AppCompatActivity):Boolean{
        val connectivityManager=context!!.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo=connectivityManager.activeNetworkInfo
        return  networkInfo!=null && networkInfo.isConnected
    }

}
