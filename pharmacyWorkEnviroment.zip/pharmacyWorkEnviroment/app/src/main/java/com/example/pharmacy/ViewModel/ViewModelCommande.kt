package com.example.pharmacy.ViewModel

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.pharmacy.Model.Commande
import com.example.pharmacy.Repo.RepoCommand
import io.reactivex.disposables.Disposable

class ViewModelCommande :ViewModel() {
    var commande=MutableLiveData<List<Commande>>()
    var repoCommand: RepoCommand = RepoCommand()


    @SuppressLint("CheckResult")
    fun getAllCommand(email:String): MutableLiveData<List<Commande>> {
       repoCommand!!.getCmdUserEmail(email).subscribe{
           commande.postValue(it)
       }

       return commande
    }
    fun createCommand (cmd :Commande){
        repoCommand.createCommand(cmd)
    }
}