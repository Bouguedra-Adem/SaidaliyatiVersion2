package com.example.pharmacy.Model.RoomDataBasePharmacy

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.room.*
import com.example.pharmacy.Model.Pharmacy
@Dao
interface DaoPharmacie {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertPharmacie(Pharmacie:Pharmacy)
    @Delete
    fun deltePharmacie(Pharmacie:Pharmacy)

    @Query("Select * from Pharmacy ")
    fun getAllPharmacie (): LiveData<List<Pharmacy>>


}