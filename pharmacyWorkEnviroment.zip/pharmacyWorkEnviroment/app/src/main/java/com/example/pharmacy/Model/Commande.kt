package com.example.pharmacy.Model

data class Commande(var nomCmd: String, var userEmail: String, var cmdState: String, var imgName: String,var dateLancement:String) {
}
