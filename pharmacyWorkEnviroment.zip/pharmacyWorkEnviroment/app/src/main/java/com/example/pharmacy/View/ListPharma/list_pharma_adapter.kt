package com.example.pharmacy.View.ListPharma

import android.app.Application
import android.app.PendingIntent.getActivity
import android.content.Context
import android.util.Log
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.example.pharmacy.Model.Pharmacy
import com.example.pharmacy.Model.RoomDataBasePharmacy.DataBase_Instance
import com.example.pharmacy.R
import com.example.pharmacy.Repo.RepoLocal_DataBase.RepoPharmacie_Local

import kotlinx.android.synthetic.main.phamra_item.view.*


class list_pharma_adapter(private val fragment: Fragment,private var Data :ArrayList<Pharmacy>): RecyclerView.Adapter<list_pharma_adapter.ViewHolder>() {



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.phamra_item, parent, false)
        return ViewHolder(view)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data: Pharmacy =Data[position]
        holder.namePharma.text=data.nomPrenomPharmacien
        holder.adr.text=data.adresse
        holder.tmp.text=data.heure
        holder.itemView.setOnClickListener{
            val RepoLocal=RepoPharmacie_Local(fragment.activity!!.application)
            RepoLocal.insertPharmacie(data)
            /*if (RepoLocal.checkExistPharma(data)!!){*/  RepoLocal.insertPharmacie(data)//}
            val dialogFragment = Pharma_detail(data)
            dialogFragment.allowEnterTransitionOverlap
            dialogFragment.show(fragment.childFragmentManager, "simple dialog")
            true
        }


    }
    fun setFilter(newsArrayList: ArrayList<Pharmacy>) {
        Data.clear()
        Data.addAll(newsArrayList)
        Log.e("datafromAdapter",Data.toString())
        notifyDataSetChanged()
    }
    override fun getItemCount(): Int {
        Log.e("sizez",Data.size.toString())
        return Data.size
    }
    inner class ViewHolder(val mView: View) : RecyclerView.ViewHolder(mView) {

       var namePharma=itemView.namePharma as TextView
        var adr=itemView.adr as TextView
        var tmp=itemView.tmp as TextView
        //var postion=itemView.position as ImageButton


    }
}
