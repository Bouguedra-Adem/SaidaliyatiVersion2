package com.example.pharmacy.Model.ApiService

class ResponseUpload(val result: Boolean, val massage: String,val name:String)