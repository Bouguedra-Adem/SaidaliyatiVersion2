package com.example.pharmacy.View.ListPharma


import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import androidx.navigation.Navigation
import androidx.navigation.findNavController
import com.example.pharmacy.Model.Pharmacy

import com.example.pharmacy.R
import kotlinx.android.synthetic.main.fragment_pharma_detail.*
import java.util.*
import kotlin.concurrent.schedule
import android.content.Intent
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.navigation.NavOptions
import androidx.navigation.fragment.findNavController


class Pharma_detail (val Data:Pharmacy): DialogFragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_pharma_detail, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val pref = activity!!.getSharedPreferences("fileName", Context.MODE_PRIVATE)
        val con = pref.getBoolean("connected", false)
        cmd.isVisible = con
        namePharma.text=Data.nomPrenomPharmacien
        adrPharma.text=Data.adresse
        tmp.text=Data.heure
        date.text=Data.dateGarde
        phone.text=Data.numeroTelephone
        casse.text=Data.caisseConventionnee
        cancel.setOnClickListener{
            Timer("DialogDismissal", false).schedule(500) { dismiss() }

        }

        locationMap.setOnClickListener{
            val bundle=Bundle()
            bundle.putString("Adr",Data.adresse)
            this.findNavController().navigate(R.id.mapFragment,bundle)
        }
        facebook.setOnClickListener{
            val uris = Uri.parse(Data.facebookUrl)
            val intents = Intent(Intent.ACTION_VIEW, uris)
            ContextCompat.startActivity(it.context, intents!!, null)
        }
        cmd.setOnClickListener {
            val bundle=Bundle()
            bundle.putString("namePharmacie",Data.nomPrenomPharmacien)
            findNavController().navigate(R.id.commandFragment,null, NavOptions.Builder()
                .setEnterAnim(R.anim.slide_out_top)
                .setPopEnterAnim(R.anim.slide_out_top)
                .setExitAnim(R.anim.slide_in_top)
                .setPopExitAnim(R.anim.slide_in_top)
                .build()
            )

        }

    }

    @SuppressLint("PrivateResource")
    override fun onStart() {

        dialog!!.window!!.setWindowAnimations(R.style.Base_Theme_MaterialComponents_Dialog_Alert)
        super.onStart()
    }


}
