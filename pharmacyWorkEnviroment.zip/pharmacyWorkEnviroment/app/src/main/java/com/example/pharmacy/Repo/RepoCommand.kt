package com.example.pharmacy.Repo

import android.util.Log
import com.example.pharmacy.Model.ApiService.ApiService
import com.example.pharmacy.Model.ApiService.ResponseUpload
import com.example.pharmacy.Model.Commande
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import java.io.File
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.MediaType
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import android.graphics.Bitmap
import android.widget.ImageView
import retrofit2.Response
import android.os.Environment.getExternalStorageDirectory
import java.io.FileOutputStream


class RepoCommand {
    var retrofitInterface = ApiService.createAvatar()
    var apiService = ApiService.create()
    fun uploadFile(file:File) {

     /*    val okHttpClient = OkHttpClient.Builder()
             .connectTimeout(1, TimeUnit.MINUTES)
             .readTimeout(30, TimeUnit.SECONDS)
             .writeTimeout(15, TimeUnit.SECONDS)
             .build()

         var retrofit = Retrofit.Builder()
             .baseUrl("https://ancient-harbor-80131.herokuapp.com/")
             .client(okHttpClient)
             .addConverterFactory(GsonConverterFactory.create())
             .build()

         var retrofitInterface = retrofit.create(RetrofitInterface::class.java)*/

        val requestFile = RequestBody.create(
            MediaType.parse("image/*"),
            file
        )
        // MultipartBody.Part is used to send also the actual file name
        val body = MultipartBody.Part.createFormData("avatar", file.getName(), requestFile)
        // add another part within the multipart request
        val descriptionString = "hello, this is description speaking"
        val description = RequestBody.create(
            okhttp3.MultipartBody.FORM, descriptionString)
        // finally, execute the request
        val call = retrofitInterface.upload(body)
        call.enqueue(object:Callback<ResponseUpload> {
            override fun onResponse(call:Call<ResponseUpload>, response:retrofit2.Response<ResponseUpload>) {
                Log.e("MUSTAPHAUPLOAD", "success")
                Log.e("MUSTAPHAUPLOAD", response.message())
                Log.e("MUSTAPHAUPLOAD", file.getName())
            }
            override fun onFailure(call:Call<ResponseUpload>, t:Throwable) {
                Log.e("MUSTAPHAUPLOAD", t.message)
            }
        })
    }


    fun downloadImage(imageview: ImageView,bitmapoficiel:Bitmap){
        imageview!!.setImageBitmap(bitmapoficiel)
        val call = retrofitInterface.getImage("4c8de049-adba-452c-b8f4-38c8fec1d303.jpg")
        call.enqueue(object:Callback<ResponseBody> {
            override fun onResponse(call:Call<ResponseBody>, response: Response<ResponseBody>) {
                try {
                    val path = getExternalStorageDirectory()
                    val file = File(path, "file_name.jpg")
                    val fileOutputStream = FileOutputStream(file)
                    fileOutputStream.write(response.body()?.bytes())

                } catch (ex: Exception) {
                }

                /*var bitmapdata = response.body()?.bytes()

                var bitmap = bitmapdata?.size?.let { BitmapFactory.decodeByteArray(bitmapdata, 0, it) }
                imageview!!.setImageBitmap(bitmap)*/
            }
            override fun onFailure(call:Call<ResponseBody>, t:Throwable) {
                Log.e("MUSTAPHAUPLOAD", t.message)
            }
        })

    }

    constructor()
    fun createCommand(cmd : Commande)=apiService.createCommand(cmd)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribeOn(Schedulers.io())

    fun getCmdUserEmail(userEmail:String)=apiService.getCmdUserEmail(userEmail)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribeOn(Schedulers.io())

    fun getCmdNon(nomCmd:String)=apiService.getCmdNon(nomCmd)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribeOn(Schedulers.io())
}

