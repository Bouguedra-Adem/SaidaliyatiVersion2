package com.example.pharmacy.View.SpalshScreen


import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible

import com.example.pharmacy.R
import com.example.pharmacy.View.MainActivity
import kotlinx.android.synthetic.main.fragment_splash_screen2.*
import androidx.appcompat.app.AlertDialog
import androidx.core.content.edit
import androidx.navigation.NavOptions
import androidx.navigation.findNavController
import com.example.pharmacy.Model.User
import com.example.pharmacy.Repo.RepoUser
import kotlinx.android.synthetic.main.fragment_splash_screen2.creer
import kotlinx.android.synthetic.main.fragment_splash_screen2.motdepass
import java.security.SecureRandom


class SplashScreen2 : Fragment() {
    var repoUser: RepoUser = RepoUser()
   var user:User ?= null
    var emailSauv=" "
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_splash_screen2, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)
        (activity as AppCompatActivity).supportActionBar!!.hide()
        suivant.setOnClickListener {
            Suivant()
        }
        back.setOnClickListener {
            constregister.isVisible=!constregister.isVisible
            consmotdepass.isVisible=!consmotdepass.isVisible
        }
        PLUSTARD.setOnClickListener {
            //activity!!.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
            val pref = activity!!.getSharedPreferences("fileName", Context.MODE_PRIVATE)
            pref.edit {
                putBoolean("connected",false)
            }
            val intent = Intent(activity!!,MainActivity::class.java)
            activity!!.overridePendingTransition(R.anim.slide_in_top, R.anim.slide_out_top);
            startActivity(intent)
            activity!!.overridePendingTransition(R.anim.slide_out_top, R.anim.slide_in_top);
        }
       creer.setOnClickListener {
           Creer()
        }
        authentifier.setOnClickListener {
            Authentifier()
        }
    }
    fun alert (){
        val builder = AlertDialog.Builder(this.context!!)
        builder.setTitle("Code Saidaliyati")
        builder.setMessage("Nous avons vous envoyée un code secret qui vous permet de continue votre inscription")
        builder.setPositiveButton("Continue", null);
        val dialog = builder.create()
        dialog.show()
    }
    @SuppressLint("CheckResult")
    fun Suivant():Boolean{
        Log.e("pass", generatePassword(true,true,true,false,6))
        if (nss.text!!.isNotEmpty() && nom.text!!.isNotEmpty() && prenom.text!!.isNotEmpty() && email.text!!.isNotEmpty() && tlp.text!!.isNotEmpty() ){
             emailSauv=email!!.text.toString()
             user=User(nom.text.toString(),
                 prenom.text.toString(),
                 email!!.text.toString(),
                 tlp.text.toString(),
                 nss.text.toString(),
                 generatePassword(true,true,true,false,6))
            Log.e("userEEE",user.toString()+" "+nom.text.toString())
            repoUser.createAccount(User(nom.text.toString(), prenom.text.toString(),  email!!.text.toString(),tlp.text.toString(),nss.text.toString(),   generatePassword(true,true,true,false,6))
            ).subscribe({
                constregister.isVisible=!constregister.isVisible
                consmotdepass.isVisible=!consmotdepass.isVisible
                alert()

            }, { error ->
                error.printStackTrace()
            })
        }
        else{
            Log.e("vide","videeee")
        }
        return false
    }
    @SuppressLint("CheckResult")
    fun Creer():Boolean{
        Log.e("info",saidaliyaticode.text!!.toString()+" "+ motdepass.text!!.toString()+" "+ conmotdepass.text!!.toString())
        if (saidaliyaticode.text!!.isNotEmpty()&& motdepass.text!!.isNotEmpty() && conmotdepass.text!!.isNotEmpty()){
            Log.e("info",saidaliyaticode.text!!.toString()+" "+ motdepass.text!!.toString()+" "+ conmotdepass.text!!.toString())
            if (motdepass!!.text.toString()==conmotdepass!!.text.toString()){
                Log.e("jjjj","ani hnaaa"+" "+emailSauv)
                repoUser!!.upDateUserPassword(this.emailSauv,saidaliyaticode.text.toString(),motdepass.text.toString())
                    .subscribe({
                        if (it.result){
                          val pref = activity!!.getSharedPreferences("fileName", Context.MODE_PRIVATE)
                          pref.edit {
                              putBoolean("connected",true)
                              putString("email",email.text.toString())
                              putString("pwd",motdepass.text.toString())

                          }
                          val intent = Intent(activity!!,MainActivity::class.java)
                            activity!!.overridePendingTransition(R.anim.slide_in_top, R.anim.slide_out_top);
                            startActivity(intent)
                            activity!!.overridePendingTransition(R.anim.slide_out_top, R.anim.slide_in_top);
                        }
                        else {
                            Log.e("msg error",it.message)
                        }
                    }, { error ->
                    error.printStackTrace()
                })
            }
        }
        return false
    }
    fun generatePassword(isWithLetters: Boolean, isWithUppercase: Boolean, isWithNumbers: Boolean, isWithSpecial: Boolean, length: Int) : String {

        var result = ""
        var i = 0

        if(isWithLetters){ result +="abcdefghijklmnopqrstuvwxyz" }
        if(isWithUppercase){ result += "ABCDEFGHIJKLMNOPQRSTUVWXYZ" }
        if(isWithNumbers){ result +="0123456789" }
        if(isWithSpecial){ result +="@#=+!£$%&?" }

        val rnd = SecureRandom.getInstance("SHA1PRNG")
        val sb = StringBuilder(length)

        while (i < length) {
            val randomInt : Int = rnd.nextInt(result.length)
            sb.append(result[randomInt])
            i++
        }

        return sb.toString()
    }
   fun Authentifier() {
       activity!!.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
          // Handler().postDelayed({
               //start fragment
               view!!.findNavController()
                   .navigate(
                       R.id.action_splashScreen22_to_login,
                       null,
                       NavOptions.Builder()
                          .setEnterAnim(R.anim.slide_out_top)
                           .setPopEnterAnim(R.anim.slide_out_top)
                           .setExitAnim(R.anim.slide_in_top)
                           .setPopExitAnim(R.anim.slide_in_top)
                           .build()
                   )
               //finish this activity
               activity!!.window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
               (activity as AppCompatActivity).supportActionBar!!.hide()
               //(activity as AppCompatActivity).onSupportNavigateUp()

         //  }, 2000)
       }
}
