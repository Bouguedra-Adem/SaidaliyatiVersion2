package com.example.pharmacy.Model.ApiService
class ResponseMessage(val result: Boolean, val message: String){}