package com.example.pharmacy.Repo

import android.util.Log
import com.example.pharmacy.Model.ApiService.ApiService
import com.example.pharmacy.Model.Pharmacy
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class RepoPharmacie {
    var apiService = ApiService.create()

    init {
       this.apiService = ApiService.create()
    }
    fun getAllPharamacy()=apiService.getAllPharmacies()
        .observeOn(AndroidSchedulers.mainThread())
        .subscribeOn(Schedulers.io())
    fun getPharamacyByCommune(commune :String)=apiService.getPharmacies(commune)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribeOn(Schedulers.io())
    fun getAllPharamacyByFilter(commune :String,dateGarde:String,Convention:String)=apiService.getAllPharmaciesByFilter(commune,dateGarde,Convention)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribeOn(Schedulers.io())
    fun getAllPharamacyByFilterDateGard(commune :String,Convention:String)=apiService.getAllPharmaciesByFilterDateGard(commune,Convention)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribeOn(Schedulers.io())


    fun getPharmaciesGardeBydate(dateGarde: String)=apiService.getPharmaciesGarde(dateGarde)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribeOn(Schedulers.io())



}