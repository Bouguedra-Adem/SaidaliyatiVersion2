package com.example.pharmacy.Repo

import com.example.pharmacy.Model.ApiService.ApiService
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class RepoCommune {
    var apiService = ApiService.create()


    init {
        this.apiService = ApiService.create()
    }

    fun getAllCommues()=apiService.getCommunes()
        .observeOn(AndroidSchedulers.mainThread())
        .subscribeOn(Schedulers.io())

    fun getCommuesByWilaya(codewilaya:String)=apiService.getCommunesByWilaya(codewilaya)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribeOn(Schedulers.io())
}